package com.dishaan.dishaan_invoice_xpert

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
