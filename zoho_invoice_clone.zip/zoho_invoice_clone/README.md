# Zoho Invoice Clone

A Flutter implementation of the Zoho Invoice dashboard UI.

## About

This project is a clone of the Zoho Invoice dashboard interface, built using Flutter and Dart. It demonstrates how to create a complex business application UI with Flutter, including responsive layouts, charts, and data tables.

## Features

- Responsive UI similar to Zoho Invoice
- Dashboard with financial statistics
- Interactive charts using fl_chart
- Custom data tables
- Sidebar navigation menu
- Projects tracking section
- Sales, Expenses and Receipts analysis

## Screenshots

[Screenshots would be added here]

## Getting Started

### Prerequisites

- Flutter SDK (2.0 or higher)
- Dart SDK
- An IDE (VS Code, Android Studio, etc.)

### Installation

1. Clone this repository:
```
git clone https://github.com/yourusername/zoho_invoice_clone.git
```

2. Navigate to the project directory:
```
cd zoho_invoice_clone
```

3. Install dependencies:
```
flutter pub get
```

4. Run the app:
```
flutter run -d chrome
```

## Project Structure

- `lib/constants/` - Contains app-wide constants and theme data
- `lib/screens/` - Screen/page implementations
- `lib/widgets/` - Reusable UI components
- `lib/models/` - Data models and business logic

## Dependencies

- [google_fonts](https://pub.dev/packages/google_fonts) - For text styling
- [fl_chart](https://pub.dev/packages/fl_chart) - For bar and line charts
- [provider](https://pub.dev/packages/provider) - For state management
- [intl](https://pub.dev/packages/intl) - For internationalization and date formatting

## License

This project is for educational purposes only. The Zoho Invoice UI design is owned by Zoho Corporation.
