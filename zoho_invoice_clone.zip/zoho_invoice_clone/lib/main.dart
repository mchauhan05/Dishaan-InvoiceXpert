import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'providers/dashboard_provider.dart';
import 'providers/invoice_provider.dart';
import 'providers/customer_provider.dart';
import 'routes/app_router.dart';
import 'constants/app_colors.dart';

void main() {
  runApp(const ZohoInvoiceApp());
}

class ZohoInvoiceApp extends StatelessWidget {
  const ZohoInvoiceApp({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MultiProvider(
      providers: [
        ChangeNotifierProvider(create: (_) => DashboardProvider()),
        ChangeNotifierProvider(create: (_) => InvoiceProvider()),
        ChangeNotifierProvider(create: (_) => CustomerProvider()),
      ],
      child: MaterialApp(
        title: 'Zoho Invoice Clone',
        debugShowCheckedModeBanner: false,
        theme: ThemeData(
          primaryColor: AppColors.primaryDark,
          scaffoldBackgroundColor: AppColors.backgroundGray,
          colorScheme: ColorScheme.fromSwatch().copyWith(
            primary: AppColors.primaryDark,
            secondary: AppColors.secondaryOrange,
            background: AppColors.backgroundGray,
          ),
          textTheme: GoogleFonts.interTextTheme(
            Theme.of(context).textTheme,
          ),
          appBarTheme: const AppBarTheme(
            backgroundColor: AppColors.primaryDark,
            foregroundColor: Colors.white,
          ),
          // Add tab theme
          tabBarTheme: TabBarTheme(
            labelColor: AppColors.primaryBlue,
            unselectedLabelColor: AppColors.textGray,
            indicator: BoxDecoration(
              border: Border(
                bottom: BorderSide(
                  color: AppColors.primaryBlue,
                  width: 2.0,
                ),
              ),
            ),
          ),
          // Add button theme
          elevatedButtonTheme: ElevatedButtonThemeData(
            style: ElevatedButton.styleFrom(
              backgroundColor: AppColors.primaryBlue,
              foregroundColor: Colors.white,
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(4),
              ),
            ),
          ),
          // Add input decoration theme
          inputDecorationTheme: InputDecorationTheme(
            filled: true,
            fillColor: Colors.white,
            contentPadding: const EdgeInsets.symmetric(horizontal: 12, vertical: 12),
            border: OutlineInputBorder(
              borderRadius: BorderRadius.circular(4),
              borderSide: BorderSide(color: AppColors.borderGray),
            ),
            enabledBorder: OutlineInputBorder(
              borderRadius: BorderRadius.circular(4),
              borderSide: BorderSide(color: AppColors.borderGray),
            ),
            focusedBorder: OutlineInputBorder(
              borderRadius: BorderRadius.circular(4),
              borderSide: BorderSide(color: AppColors.primaryBlue),
            ),
            hintStyle: TextStyle(color: AppColors.textGray),
          ),
        ),
        onGenerateRoute: AppRouter.generateRoute,
        initialRoute: AppRouter.dashboard,
      ),
    );
  }
}
