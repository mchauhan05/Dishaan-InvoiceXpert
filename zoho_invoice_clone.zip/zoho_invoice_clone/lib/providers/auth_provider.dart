import 'dart:async';
import 'package:flutter/material.dart';
import '../models/auth_model.dart';

class AuthProvider extends ChangeNotifier {
  User? _currentUser;
  AuthToken? _authToken;
  bool _isLoading = false;
  String? _error;

  // Getters
  User? get currentUser => _currentUser;
  bool get isAuthenticated => _currentUser != null && _authToken != null;
  bool get isLoading => _isLoading;
  String? get error => _error;

  // Constructor with sample user for demo
  AuthProvider() {
    // Initialize with a sample user for demo purposes
    _initializeSampleUser();
  }

  // Initialize sample user
  void _initializeSampleUser() {
    final now = DateTime.now();

    _currentUser = User(
      id: 'USR-001',
      email: 'demo@example.com',
      firstName: 'Demo',
      lastName: 'User',
      profileImageUrl: null,
      role: UserRole.admin,
      status: AccountStatus.active,
      createdAt: now.subtract(const Duration(days: 30)),
      lastLogin: now,
      permissions: [
        'invoices.view',
        'invoices.create',
        'customers.view',
        'products.view',
        'reports.view',
      ],
    );

    _authToken = AuthToken(
      token: 'mock-token',
      expiresAt: now.add(const Duration(hours: 1)),
      refreshToken: 'refresh-token',
    );

    notifyListeners();
  }

  // Log in user
  Future<bool> login(String email, String password) async {
    _error = null;
    _isLoading = true;
    notifyListeners();

    try {
      await Future.delayed(const Duration(seconds: 1));

      if (email == 'demo@example.com' && password == 'password') {
        _initializeSampleUser();
        _isLoading = false;
        notifyListeners();
        return true;
      } else {
        _error = 'Invalid email or password';
        _isLoading = false;
        notifyListeners();
        return false;
      }
    } catch (e) {
      _error = 'Login failed: ${e.toString()}';
      _isLoading = false;
      notifyListeners();
      return false;
    }
  }

  // Log out
  Future<void> logout() async {
    _isLoading = true;
    notifyListeners();

    await Future.delayed(const Duration(milliseconds: 500));

    _currentUser = null;
    _authToken = null;
    _isLoading = false;
    notifyListeners();
  }

  // Reset password
  Future<bool> resetPassword(String email) async {
    _error = null;
    _isLoading = true;
    notifyListeners();

    try {
      await Future.delayed(const Duration(seconds: 1));
      _isLoading = false;
      notifyListeners();
      return true;
    } catch (e) {
      _error = 'Password reset failed: ${e.toString()}';
      _isLoading = false;
      notifyListeners();
      return false;
    }
  }
}
