import 'dart:math';
import 'package:flutter/material.dart';
import '../models/product_model.dart';

class ProductProvider extends ChangeNotifier {
  // List of products
  final List<Product> _products = [];

  // Categories
  final List<String> _categories = [
    'Electronics',
    'Furniture',
    'Clothing',
    'Food & Beverages',
    'Office Supplies',
    'Software',
    'Hardware',
    'Accessories',
    'Books',
    'Services',
  ];

  // Currently selected product
  Product? _currentProduct;

  // Getters
  List<Product> get products => _products;
  Product? get currentProduct => _currentProduct;
  List<String> get categories => _categories;

  // Constructor with sample data
  ProductProvider() {
    _loadSampleProducts();
  }

  // Load sample products
  void _loadSampleProducts() {
    final now = DateTime.now();

    _products.addAll([
      Product(
        id: 'PROD-001',
        sku: 'LT-001',
        barcode: '7890123456789',
        name: 'Laptop Pro 15"',
        description: 'High performance laptop with 16GB RAM and 512GB SSD',
        sellingPrice: 1299.99,
        costPrice: 899.99,
        weight: 2.1,
        unit: 'piece',
        dimensions: '36 x 25 x 1.8 cm',
        manufacturer: 'TechCorp',
        brand: 'ProBook',
        type: ProductType.goods,
        taxType: TaxType.taxable,
        taxRate: 7.5,
        category: 'Electronics',
        inventoryTracking: InventoryTracking.track,
        stockQuantity: 25,
        lowStockAlert: 5,
        imageUrl: 'https://example.com/images/laptop-pro.jpg',
        createdAt: now.subtract(const Duration(days: 100)),
        updatedAt: now.subtract(const Duration(days: 30)),
      ),
      Product(
        id: 'PROD-002',
        sku: 'MB-002',
        barcode: '9876543210987',
        name: 'Wireless Mouse',
        description: 'Ergonomic wireless mouse with long battery life',
        sellingPrice: 49.99,
        costPrice: 22.50,
        weight: 0.12,
        unit: 'piece',
        dimensions: '10 x 6 x 3.5 cm',
        manufacturer: 'PeripheralTech',
        brand: 'ComfortPoint',
        type: ProductType.goods,
        taxType: TaxType.taxable,
        taxRate: 7.5,
        category: 'Electronics',
        inventoryTracking: InventoryTracking.track,
        stockQuantity: 42,
        lowStockAlert: 10,
        imageUrl: 'https://example.com/images/wireless-mouse.jpg',
        createdAt: now.subtract(const Duration(days: 75)),
        updatedAt: now.subtract(const Duration(days: 15)),
      ),
      Product(
        id: 'PROD-003',
        sku: 'KB-003',
        barcode: '1234567890123',
        name: 'Mechanical Keyboard',
        description: 'RGB backlit mechanical keyboard with Cherry MX switches',
        sellingPrice: 129.99,
        costPrice: 75.00,
        weight: 1.1,
        unit: 'piece',
        dimensions: '44 x 14 x 4 cm',
        manufacturer: 'PeripheralTech',
        brand: 'KeyMaster',
        type: ProductType.goods,
        taxType: TaxType.taxable,
        taxRate: 7.5,
        category: 'Electronics',
        inventoryTracking: InventoryTracking.track,
        stockQuantity: 0,
        lowStockAlert: 5,
        imageUrl: 'https://example.com/images/mechanical-keyboard.jpg',
        createdAt: now.subtract(const Duration(days: 60)),
        updatedAt: now.subtract(const Duration(days: 10)),
      ),
      Product(
        id: 'PROD-004',
        sku: 'SVC-001',
        barcode: '5678901234567',
        name: 'Website Design',
        description: 'Professional website design service including responsive layouts',
        sellingPrice: 1500.00,
        type: ProductType.service,
        taxType: TaxType.exempt,
        category: 'Services',
        inventoryTracking: InventoryTracking.dontTrack,
        createdAt: now.subtract(const Duration(days: 45)),
        updatedAt: now.subtract(const Duration(days: 45)),
      ),
      Product(
        id: 'PROD-005',
        sku: 'SVC-002',
        barcode: '6789012345678',
        name: 'IT Consultation',
        description: 'Hourly IT consultation services',
        sellingPrice: 120.00,
        type: ProductType.service,
        taxType: TaxType.taxable,
        taxRate: 7.5,
        category: 'Services',
        inventoryTracking: InventoryTracking.dontTrack,
        createdAt: now.subtract(const Duration(days: 30)),
        updatedAt: now.subtract(const Duration(days: 5)),
      ),
    ]);
  }

  // Generate a unique barcode
  String generateBarcode() {
    final random = Random();
    String barcode;

    do {
      // Generate a 13-digit EAN-13 barcode
      // In a real application, we'd use proper barcode validation
      final List<int> digits = List.generate(12, (_) => random.nextInt(10));

      // Calculate check digit (simplified here)
      int sum = 0;
      for (int i = 0; i < 12; i++) {
        sum += digits[i] * (i % 2 == 0 ? 1 : 3);
      }
      final int checkDigit = (10 - (sum % 10)) % 10;

      digits.add(checkDigit);
      barcode = digits.join();
    } while (_barcodeExists(barcode));

    return barcode;
  }

  // Check if barcode exists
  bool _barcodeExists(String barcode) {
    return _products.any((product) => product.barcode == barcode);
  }

  // Generate a unique SKU
  String generateSku(String prefix, int padding) {
    int highestNumber = 0;

    // Find the highest existing SKU with this prefix
    for (final product in _products) {
      if (product.sku.startsWith(prefix)) {
        try {
          final numberPart = product.sku.substring(prefix.length);
          final number = int.parse(numberPart);
          if (number > highestNumber) {
            highestNumber = number;
          }
        } catch (e) {
          // Not a number, skip this SKU
        }
      }
    }

    // Generate the new SKU number
    final nextNumber = highestNumber + 1;
    return '$prefix${nextNumber.toString().padLeft(padding, '0')}';
  }

  // Add a new product
  void addProduct(Product product) {
    _products.add(product);
    notifyListeners();
  }

  // Update an existing product
  void updateProduct(Product updatedProduct) {
    final index = _products.indexWhere((p) => p.id == updatedProduct.id);
    if (index >= 0) {
      _products[index] = updatedProduct;
      notifyListeners();
    }
  }

  // Delete a product
  void deleteProduct(String productId) {
    _products.removeWhere((p) => p.id == productId);
    if (_currentProduct?.id == productId) {
      _currentProduct = null;
    }
    notifyListeners();
  }

  // Set current product
  void setCurrentProduct(String productId) {
    _currentProduct = _products.firstWhere(
      (p) => p.id == productId,
      orElse: () => _products.first,
    );
    notifyListeners();
  }

  // Clear current product
  void clearCurrentProduct() {
    _currentProduct = null;
    notifyListeners();
  }

  // Add a new category
  void addCategory(String category) {
    if (!_categories.contains(category)) {
      _categories.add(category);
      notifyListeners();
    }
  }

  // Get products by category
  List<Product> getProductsByCategory(String category) {
    return _products.where((p) => p.category == category).toList();
  }

  // Search products
  List<Product> searchProducts(String query) {
    if (query.isEmpty) return _products;

    final lowercaseQuery = query.toLowerCase();
    return _products.where((p) =>
      p.name.toLowerCase().contains(lowercaseQuery) ||
      p.description.toLowerCase().contains(lowercaseQuery) ||
      p.sku.toLowerCase().contains(lowercaseQuery) ||
      p.barcode.contains(query)
    ).toList();
  }

  // Get products with low stock
  List<Product> get lowStockProducts {
    return _products.where((p) =>
      p.inventoryTracking == InventoryTracking.track && p.isLowStock
    ).toList();
  }

  // Get out of stock products
  List<Product> get outOfStockProducts {
    return _products.where((p) =>
      p.inventoryTracking == InventoryTracking.track &&
      p.stockQuantity != null && p.stockQuantity! <= 0
    ).toList();
  }

  // Update stock quantity
  void updateStock(String productId, int quantity) {
    final index = _products.indexWhere((p) => p.id == productId);
    if (index >= 0) {
      final product = _products[index];
      if (product.inventoryTracking == InventoryTracking.track && product.stockQuantity != null) {
        final updatedProduct = product.copyWith(
          stockQuantity: product.stockQuantity! + quantity,
          updatedAt: DateTime.now(),
        );
        _products[index] = updatedProduct;

        if (_currentProduct?.id == productId) {
          _currentProduct = updatedProduct;
        }

        notifyListeners();
      }
    }
  }
}
