import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../models/invoice_models.dart';
import '../widgets/sidebar.dart';
import '../widgets/header.dart';
import '../constants/app_colors.dart';
import '../providers/invoice_provider.dart';
import '../providers/settings_provider.dart';
import '../utils/pdf_generator.dart';
import '../routes/app_router.dart';

class InvoicePreviewScreen extends StatefulWidget {
  final String? invoiceId;

  const InvoicePreviewScreen({
    Key? key,
    this.invoiceId,
  }) : super(key: key);

  @override
  State<InvoicePreviewScreen> createState() => _InvoicePreviewScreenState();
}

class _InvoicePreviewScreenState extends State<InvoicePreviewScreen> {
  bool _isLoading = false;
  String? _errorMessage;
  Invoice? _invoice;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      _loadInvoice();
    });
  }

  Future<void> _loadInvoice() async {
    final invoiceProvider = Provider.of<InvoiceProvider>(context, listen: false);

    setState(() {
      _isLoading = true;
      _errorMessage = null;
    });

    try {
      if (widget.invoiceId != null) {
        // Load existing invoice
        invoiceProvider.loadInvoiceForEditing(widget.invoiceId!);
      }

      setState(() {
        _invoice = invoiceProvider.currentInvoice;
        _isLoading = false;
      });
    } catch (e) {
      setState(() {
        _errorMessage = 'Failed to load invoice: ${e.toString()}';
        _isLoading = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    final settingsProvider = Provider.of<SettingsProvider>(context);

    if (_isLoading) {
      return const Scaffold(
        body: Center(
          child: CircularProgressIndicator(),
        ),
      );
    }

    if (_errorMessage != null) {
      return Scaffold(
        body: Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(
                Icons.error_outline,
                color: Colors.red,
                size: 64,
              ),
              const SizedBox(height: 16),
              Text(
                'Error',
                style: TextStyle(
                  fontSize: 24,
                  fontWeight: FontWeight.bold,
                ),
              ),
              const SizedBox(height: 8),
              Text(_errorMessage!),
              const SizedBox(height: 24),
              ElevatedButton(
                onPressed: () {
                  Navigator.pop(context);
                },
                child: const Text('Go Back'),
              ),
            ],
          ),
        ),
      );
    }

    if (_invoice == null) {
      return Scaffold(
        body: Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(
                Icons.description_outlined,
                color: AppColors.textGray,
                size: 64,
              ),
              const SizedBox(height: 16),
              Text(
                'Invoice Not Found',
                style: TextStyle(
                  fontSize: 24,
                  fontWeight: FontWeight.bold,
                ),
              ),
              const SizedBox(height: 24),
              ElevatedButton(
                onPressed: () {
                  Navigator.pop(context);
                },
                child: const Text('Go Back'),
              ),
            ],
          ),
        ),
      );
    }

    return Scaffold(
      backgroundColor: AppColors.backgroundGray,
      body: Row(
        children: [
          // Sidebar
          Sidebar(currentRoute: AppRouter.invoices),

          // Main content
          Expanded(
            child: Column(
              children: [
                // Header
                const Header(),

                // Content
                Expanded(
                  child: SingleChildScrollView(
                    padding: const EdgeInsets.all(24),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        // Page title and actions
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Text(
                              'Invoice Preview',
                              style: TextStyle(
                                fontSize: 24,
                                fontWeight: FontWeight.bold,
                                color: AppColors.primaryDark,
                              ),
                            ),
                            Row(
                              children: [
                                // Go back button
                                OutlinedButton.icon(
                                  onPressed: () {
                                    Navigator.pop(context);
                                  },
                                  icon: const Icon(Icons.arrow_back),
                                  label: const Text('Back'),
                                  style: OutlinedButton.styleFrom(
                                    foregroundColor: AppColors.textGray,
                                    side: BorderSide(color: AppColors.borderGray),
                                    padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
                                  ),
                                ),
                                const SizedBox(width: 16),
                                // Actions dropdown
                                _buildActionsDropdown(context, settingsProvider),
                              ],
                            ),
                          ],
                        ),
                        const SizedBox(height: 24),

                        // Preview container
                        Container(
                          decoration: BoxDecoration(
                            color: Colors.white,
                            boxShadow: [
                              BoxShadow(
                                color: Colors.black.withOpacity(0.1),
                                blurRadius: 10,
                                offset: const Offset(0, 5),
                              ),
                            ],
                          ),
                          child: Column(
                            children: [
                              // Toolbar
                              Container(
                                padding: const EdgeInsets.all(16),
                                decoration: BoxDecoration(
                                  border: Border(
                                    bottom: BorderSide(color: AppColors.borderGray),
                                  ),
                                ),
                                child: Row(
                                  children: [
                                    Text(
                                      'Invoice ${_invoice!.invoiceNumber}',
                                      style: const TextStyle(
                                        fontWeight: FontWeight.bold,
                                      ),
                                    ),
                                    const Spacer(),
                                    // Print button
                                    IconButton(
                                      onPressed: () => _printInvoice(settingsProvider),
                                      icon: const Icon(Icons.print),
                                      tooltip: 'Print Invoice',
                                    ),
                                    // Download button
                                    IconButton(
                                      onPressed: () => _downloadPdf(settingsProvider),
                                      icon: const Icon(Icons.download),
                                      tooltip: 'Download PDF',
                                    ),
                                    // Email button
                                    IconButton(
                                      onPressed: () => _emailInvoice(settingsProvider),
                                      icon: const Icon(Icons.email),
                                      tooltip: 'Email Invoice',
                                    ),
                                  ],
                                ),
                              ),

                              // Preview content
                              SizedBox(
                                width: double.infinity,
                                child: SingleChildScrollView(
                                  padding: const EdgeInsets.all(16),
                                  child: PdfGenerator.getInvoicePreview(_invoice!, settingsProvider.settings),
                                ),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildActionsDropdown(BuildContext context, SettingsProvider settingsProvider) {
    return PopupMenuButton<String>(
      onSelected: (value) {
        switch (value) {
          case 'edit':
            Navigator.pop(context);
            break;
          case 'print':
            _printInvoice(settingsProvider);
            break;
          case 'download':
            _downloadPdf(settingsProvider);
            break;
          case 'email':
            _emailInvoice(settingsProvider);
            break;
          case 'mark_sent':
            _markAsSent();
            break;
          case 'mark_paid':
            _markAsPaid();
            break;
        }
      },
      itemBuilder: (context) => [
        const PopupMenuItem<String>(
          value: 'edit',
          child: Row(
            children: [
              Icon(Icons.edit, size: 20),
              SizedBox(width: 8),
              Text('Edit Invoice'),
            ],
          ),
        ),
        const PopupMenuItem<String>(
          value: 'print',
          child: Row(
            children: [
              Icon(Icons.print, size: 20),
              SizedBox(width: 8),
              Text('Print'),
            ],
          ),
        ),
        const PopupMenuItem<String>(
          value: 'download',
          child: Row(
            children: [
              Icon(Icons.download, size: 20),
              SizedBox(width: 8),
              Text('Download PDF'),
            ],
          ),
        ),
        const PopupMenuItem<String>(
          value: 'email',
          child: Row(
            children: [
              Icon(Icons.email, size: 20),
              SizedBox(width: 8),
              Text('Send via Email'),
            ],
          ),
        ),
        const PopupMenuItem<String>(
          value: 'mark_sent',
          child: Row(
            children: [
              Icon(Icons.check_circle_outline, size: 20),
              SizedBox(width: 8),
              Text('Mark as Sent'),
            ],
          ),
        ),
        const PopupMenuItem<String>(
          value: 'mark_paid',
          child: Row(
            children: [
              Icon(Icons.attach_money, size: 20),
              SizedBox(width: 8),
              Text('Mark as Paid'),
            ],
          ),
        ),
      ],
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
        decoration: BoxDecoration(
          color: AppColors.primaryBlue,
          borderRadius: BorderRadius.circular(4),
        ),
        child: Row(
          children: [
            const Text(
              'Actions',
              style: TextStyle(
                color: Colors.white,
                fontWeight: FontWeight.w500,
              ),
            ),
            const SizedBox(width: 8),
            const Icon(
              Icons.arrow_drop_down,
              color: Colors.white,
            ),
          ],
        ),
      ),
    );
  }

  Future<void> _printInvoice(SettingsProvider settingsProvider) async {
    if (_invoice == null) return;

    setState(() {
      _isLoading = true;
    });

    try {
      await PdfGenerator.printInvoice(_invoice!, settingsProvider.settings);

      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('Invoice sent to printer successfully'),
          ),
        );
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Failed to print invoice: ${e.toString()}'),
            backgroundColor: Colors.red,
          ),
        );
      }
    } finally {
      if (mounted) {
        setState(() {
          _isLoading = false;
        });
      }
    }
  }

  Future<void> _downloadPdf(SettingsProvider settingsProvider) async {
    if (_invoice == null) return;

    setState(() {
      _isLoading = true;
    });

    try {
      final filePath = await PdfGenerator.saveInvoicePdf(_invoice!, settingsProvider.settings);

      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Invoice saved to $filePath'),
          ),
        );
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Failed to save invoice: ${e.toString()}'),
            backgroundColor: Colors.red,
          ),
        );
      }
    } finally {
      if (mounted) {
        setState(() {
          _isLoading = false;
        });
      }
    }
  }

  Future<void> _emailInvoice(SettingsProvider settingsProvider) async {
    if (_invoice == null) return;

    setState(() {
      _isLoading = true;
    });

    try {
      await PdfGenerator.emailInvoice(_invoice!, settingsProvider.settings);

      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('Invoice sent via email successfully'),
          ),
        );
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Failed to email invoice: ${e.toString()}'),
            backgroundColor: Colors.red,
          ),
        );
      }
    } finally {
      if (mounted) {
        setState(() {
          _isLoading = false;
        });
      }
    }
  }

  void _markAsSent() {
    // This would update the invoice status to sent
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(
        content: Text('Invoice marked as sent'),
      ),
    );
  }

  void _markAsPaid() {
    // This would update the invoice status to paid
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(
        content: Text('Invoice marked as paid'),
      ),
    );
  }
}
