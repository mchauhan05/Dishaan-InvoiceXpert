import 'dart:typed_data';
import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:intl/intl.dart';
import '../models/invoice_models.dart';
import '../models/settings_model.dart';

/// A utility class to generate PDF invoices
class PdfGenerator {
  // This would be a mock implementation since we can't directly implement PDF generation
  // In a real implementation, we would use packages like pdf, printing, or flutter_html_to_pdf

  /// Generate a PDF invoice from the provided invoice data
  ///
  /// Returns a future that resolves to a ByteData representing the PDF
  static Future<ByteData> generateInvoicePdf(Invoice invoice, AppSettings settings) async {
    // In a real implementation, this would create an actual PDF
    // For now, we'll just simulate the process

    // Simulate PDF generation process
    await Future.delayed(const Duration(seconds: 1));

    // Create a mock PDF byte data (this would be the real PDF data in production)
    final mockPdfData = ByteData(1024);

    return mockPdfData;
  }

  /// Print the invoice to a physical printer
  static Future<bool> printInvoice(Invoice invoice, AppSettings settings) async {
    // Simulate printing process
    await Future.delayed(const Duration(seconds: 2));

    // Return success
    return true;
  }

  /// Email the invoice to the customer
  static Future<bool> emailInvoice(
    Invoice invoice,
    AppSettings settings,
    {String? additionalMessage}
  ) async {
    // Simulate email sending process
    await Future.delayed(const Duration(seconds: 2));

    // Return success
    return true;
  }

  /// Save the invoice PDF to the device (this is a mock implementation)
  static Future<String> saveInvoicePdf(Invoice invoice, AppSettings settings) async {
    // Generate the PDF
    final pdfData = await generateInvoicePdf(invoice, settings);

    // Simulate saving to file system
    await Future.delayed(const Duration(seconds: 1));

    // Return a mock file path
    return '/downloads/invoice_${invoice.invoiceNumber}.pdf';
  }

  /// Returns a preview of how the invoice would look
  /// In a real application, this would return a Widget that renders a preview
  static Widget getInvoicePreview(Invoice invoice, AppSettings settings) {
    return _InvoicePreviewWidget(invoice: invoice, settings: settings);
  }
}

/// A widget that displays a preview of the invoice
/// This would normally render a preview similar to the PDF output
class _InvoicePreviewWidget extends StatelessWidget {
  final Invoice invoice;
  final AppSettings settings;

  const _InvoicePreviewWidget({
    Key? key,
    required this.invoice,
    required this.settings,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final currencyFormatter = NumberFormat.currency(
      symbol: settings.currencySettings.currencySymbol,
      decimalDigits: settings.currencySettings.decimalPlaces,
    );

    return Container(
      color: Colors.white,
      padding: const EdgeInsets.all(24),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Header with company info and invoice details
          Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // Company info
              Expanded(
                flex: 2,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      settings.companyProfile.companyName,
                      style: const TextStyle(
                        fontSize: 24,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    const SizedBox(height: 8),
                    Text(settings.companyProfile.address),
                    Text('${settings.companyProfile.city}, ${settings.companyProfile.state} ${settings.companyProfile.zipCode}'),
                    Text(settings.companyProfile.country),
                    const SizedBox(height: 8),
                    Text('Phone: ${settings.companyProfile.phone}'),
                    Text('Email: ${settings.companyProfile.email}'),
                    if (settings.companyProfile.website.isNotEmpty)
                      Text('Web: ${settings.companyProfile.website}'),
                  ],
                ),
              ),

              // Invoice info
              Expanded(
                flex: 1,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.end,
                  children: [
                    Container(
                      padding: const EdgeInsets.all(8),
                      color: Colors.grey[200],
                      child: Text(
                        'INVOICE',
                        style: const TextStyle(
                          fontSize: 24,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ),
                    const SizedBox(height: 16),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        const Text('Invoice Number:'),
                        Text(invoice.invoiceNumber),
                      ],
                    ),
                    const SizedBox(height: 8),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        const Text('Invoice Date:'),
                        Text(DateFormat('MM/dd/yyyy').format(invoice.date)),
                      ],
                    ),
                    const SizedBox(height: 8),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        const Text('Due Date:'),
                        Text(DateFormat('MM/dd/yyyy').format(invoice.dueDate)),
                      ],
                    ),
                    if (invoice.status == InvoiceStatus.paid)
                      Container(
                        margin: const EdgeInsets.only(top: 16),
                        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                        color: Colors.green[100],
                        child: const Text(
                          'PAID',
                          style: TextStyle(
                            color: Colors.green,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ),
                  ],
                ),
              ),
            ],
          ),

          const SizedBox(height: 40),

          // Bill to section
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text(
                'Bill To:',
                style: TextStyle(
                  fontWeight: FontWeight.bold,
                ),
              ),
              const SizedBox(height: 8),
              Text(
                invoice.customer.name,
                style: const TextStyle(
                  fontSize: 16,
                  fontWeight: FontWeight.bold,
                ),
              ),
              Text(invoice.customer.billingAddress),
              Text(invoice.customer.email),
              Text(invoice.customer.phone),
            ],
          ),

          const SizedBox(height: 32),

          // Items table
          Column(
            children: [
              // Table header
              Container(
                padding: const EdgeInsets.symmetric(vertical: 8, horizontal: 12),
                color: Colors.grey[200],
                child: Row(
                  children: [
                    Expanded(
                      flex: 6,
                      child: Text(
                        'DESCRIPTION',
                        style: const TextStyle(fontWeight: FontWeight.bold),
                      ),
                    ),
                    Expanded(
                      flex: 1,
                      child: Text(
                        'QTY',
                        style: const TextStyle(fontWeight: FontWeight.bold),
                        textAlign: TextAlign.center,
                      ),
                    ),
                    Expanded(
                      flex: 2,
                      child: Text(
                        'RATE',
                        style: const TextStyle(fontWeight: FontWeight.bold),
                        textAlign: TextAlign.right,
                      ),
                    ),
                    Expanded(
                      flex: 2,
                      child: Text(
                        'AMOUNT',
                        style: const TextStyle(fontWeight: FontWeight.bold),
                        textAlign: TextAlign.right,
                      ),
                    ),
                  ],
                ),
              ),

              // Table items
              ...invoice.items.map((item) => Container(
                padding: const EdgeInsets.symmetric(vertical: 8, horizontal: 12),
                decoration: BoxDecoration(
                  border: Border(
                    bottom: BorderSide(color: Colors.grey[300]!),
                  ),
                ),
                child: Row(
                  children: [
                    Expanded(
                      flex: 6,
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            item.name,
                            style: const TextStyle(fontWeight: FontWeight.bold),
                          ),
                          if (item.description.isNotEmpty)
                            Text(
                              item.description,
                              style: TextStyle(
                                color: Colors.grey[600],
                                fontSize: 12,
                              ),
                            ),
                        ],
                      ),
                    ),
                    Expanded(
                      flex: 1,
                      child: Text(
                        item.quantity.toString(),
                        textAlign: TextAlign.center,
                      ),
                    ),
                    Expanded(
                      flex: 2,
                      child: Text(
                        currencyFormatter.format(item.rate),
                        textAlign: TextAlign.right,
                      ),
                    ),
                    Expanded(
                      flex: 2,
                      child: Text(
                        currencyFormatter.format(item.amount),
                        textAlign: TextAlign.right,
                      ),
                    ),
                  ],
                ),
              )).toList(),

              // Totals section
              Container(
                padding: const EdgeInsets.only(right: 12, top: 16),
                child: Column(
                  children: [
                    Row(
                      children: [
                        const Spacer(flex: 7),
                        Expanded(
                          flex: 2,
                          child: Text(
                            'Subtotal',
                            textAlign: TextAlign.right,
                          ),
                        ),
                        Expanded(
                          flex: 2,
                          child: Text(
                            currencyFormatter.format(invoice.subtotal),
                            textAlign: TextAlign.right,
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 8),
                    if (invoice.totalTax > 0)
                      Row(
                        children: [
                          const Spacer(flex: 7),
                          Expanded(
                            flex: 2,
                            child: Text(
                              'Tax',
                              textAlign: TextAlign.right,
                            ),
                          ),
                          Expanded(
                            flex: 2,
                            child: Text(
                              currencyFormatter.format(invoice.totalTax),
                              textAlign: TextAlign.right,
                            ),
                          ),
                        ],
                      ),
                    const SizedBox(height: 8),
                    Row(
                      children: [
                        const Spacer(flex: 7),
                        Expanded(
                          flex: 2,
                          child: Text(
                            'Total',
                            style: const TextStyle(fontWeight: FontWeight.bold),
                            textAlign: TextAlign.right,
                          ),
                        ),
                        Expanded(
                          flex: 2,
                          child: Text(
                            currencyFormatter.format(invoice.total),
                            style: const TextStyle(fontWeight: FontWeight.bold),
                            textAlign: TextAlign.right,
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ],
          ),

          const SizedBox(height: 32),

          // Notes and terms
          if (invoice.notes.isNotEmpty || invoice.terms.isNotEmpty)
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                if (invoice.notes.isNotEmpty)
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Text(
                        'Notes',
                        style: TextStyle(fontWeight: FontWeight.bold),
                      ),
                      const SizedBox(height: 4),
                      Text(invoice.notes),
                      const SizedBox(height: 16),
                    ],
                  ),
                if (invoice.terms.isNotEmpty)
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Text(
                        'Terms & Conditions',
                        style: TextStyle(fontWeight: FontWeight.bold),
                      ),
                      const SizedBox(height: 4),
                      Text(invoice.terms),
                    ],
                  ),
              ],
            ),

          const SizedBox(height: 32),

          // Footer with thank you message
          Center(
            child: Text(
              'Thank you for your business!',
              style: const TextStyle(
                fontStyle: FontStyle.italic,
                color: Colors.grey,
              ),
            ),
          ),
        ],
      ),
    );
  }
}
