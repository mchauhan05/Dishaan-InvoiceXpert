import 'package:flutter/material.dart';
import '../constants/app_colors.dart';

class Header extends StatelessWidget {
  const Header({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 56,
      decoration: BoxDecoration(
        color: Colors.white,
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.05),
            blurRadius: 4,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      padding: const EdgeInsets.symmetric(horizontal: 16),
      child: Row(
        children: [
          // Refresh button
          IconButton(
            icon: const Icon(Icons.refresh, color: AppColors.textGray),
            onPressed: () {},
          ),
          const SizedBox(width: 8),
          // Search bar
          Expanded(
            child: Container(
              height: 36,
              decoration: BoxDecoration(
                color: AppColors.backgroundGray,
                borderRadius: BorderRadius.circular(4),
                border: Border.all(color: AppColors.borderGray),
              ),
              padding: const EdgeInsets.symmetric(horizontal: 12),
              child: Row(
                children: [
                  const Icon(Icons.search, color: AppColors.textGray, size: 20),
                  const SizedBox(width: 8),
                  Expanded(
                    child: TextField(
                      decoration: InputDecoration(
                        hintText: 'Search in Customers ( / )',
                        hintStyle: TextStyle(
                          color: AppColors.textGray,
                          fontSize: 14,
                        ),
                        border: InputBorder.none,
                        contentPadding: const EdgeInsets.symmetric(vertical: 8),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
          const SizedBox(width: 16),
          // Organization info
          Text(
            'This is a Test organization.',
            style: TextStyle(
              color: AppColors.textGray,
              fontSize: 14,
            ),
          ),
          const SizedBox(width: 16),
          // Demo org dropdown
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(4),
              border: Border.all(color: AppColors.borderGray),
            ),
            child: Row(
              children: [
                Text(
                  'Demo Org',
                  style: TextStyle(
                    color: AppColors.primaryDark,
                    fontSize: 14,
                    fontWeight: FontWeight.w500,
                  ),
                ),
                const SizedBox(width: 4),
                const Icon(Icons.arrow_drop_down, color: AppColors.primaryDark),
              ],
            ),
          ),
          const SizedBox(width: 8),
          // Add new button
          Container(
            width: 36,
            height: 36,
            decoration: BoxDecoration(
              color: AppColors.primaryBlue,
              borderRadius: BorderRadius.circular(4),
            ),
            child: const Icon(Icons.add, color: Colors.white),
          ),
          const SizedBox(width: 8),
          // Notifications
          IconButton(
            icon: const Icon(Icons.notifications_none, color: AppColors.textGray),
            onPressed: () {},
          ),
          // Settings
          IconButton(
            icon: const Icon(Icons.settings, color: AppColors.textGray),
            onPressed: () {},
          ),
          // User avatar
          Container(
            width: 36,
            height: 36,
            decoration: BoxDecoration(
              color: AppColors.backgroundGray,
              shape: BoxShape.circle,
              border: Border.all(color: AppColors.borderGray),
            ),
            child: CircleAvatar(
              backgroundColor: Colors.white,
              child: Text(
                'D',
                style: TextStyle(
                  color: AppColors.primaryDark,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
