import 'package:flutter/material.dart';
import '../constants/app_colors.dart';

class ProjectsCard extends StatelessWidget {
  const ProjectsCard({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.only(bottom: 16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(4),
        border: Border.all(color: AppColors.borderGray),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Header
          Padding(
            padding: const EdgeInsets.all(16),
            child: Row(
              children: [
                const Text(
                  'Projects',
                  style: TextStyle(
                    fontSize: 16,
                    fontWeight: FontWeight.w500,
                  ),
                ),
              ],
            ),
          ),

          // Unbilled stats
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            child: Row(
              children: [
                _buildUnbilledStat(
                  'Unbilled Hours',
                  '12:00',
                  Icons.access_time,
                ),
                const SizedBox(width: 32),
                _buildUnbilledStat(
                  'Unbilled Expenses',
                  '\$100.00',
                  Icons.receipt_long,
                ),
              ],
            ),
          ),

          const SizedBox(height: 24),

          // Project 1
          _buildProjectItem(
            'Sleek Rubber Computer',
            'Ethan Clark',
            0.7, // 70% of budget hours
          ),

          const Divider(height: 1, thickness: 1, color: AppColors.borderGray),

          // Project 2
          _buildProjectItem(
            'Luxurious Granite Mouse',
            'Sophia Hall',
            0.4, // 40% of budget hours
          ),

          // Show all projects button
          Padding(
            padding: const EdgeInsets.all(16),
            child: Center(
              child: TextButton(
                onPressed: () {},
                child: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Text(
                      'Show All Projects',
                      style: TextStyle(
                        color: AppColors.primaryBlue,
                        fontSize: 14,
                      ),
                    ),
                    const SizedBox(width: 4),
                    Icon(
                      Icons.arrow_forward,
                      color: AppColors.primaryBlue,
                      size: 16,
                    ),
                  ],
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildUnbilledStat(String label, String value, IconData icon) {
    return Row(
      children: [
        Container(
          width: 32,
          height: 32,
          decoration: BoxDecoration(
            color: AppColors.backgroundGray,
            borderRadius: BorderRadius.circular(4),
          ),
          child: Icon(
            icon,
            color: AppColors.textGray,
            size: 16,
          ),
        ),
        const SizedBox(width: 8),
        Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              label,
              style: TextStyle(
                color: AppColors.textGray,
                fontSize: 12,
              ),
            ),
            const SizedBox(height: 2),
            Text(
              value,
              style: TextStyle(
                fontSize: 14,
                fontWeight: FontWeight.w500,
              ),
            ),
          ],
        ),
      ],
    );
  }

  Widget _buildProjectItem(String projectName, String clientName, double progressValue) {
    return Padding(
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Project name with link icon
          Row(
            children: [
              Text(
                projectName,
                style: TextStyle(
                  color: AppColors.primaryBlue,
                  fontSize: 14,
                  fontWeight: FontWeight.w500,
                ),
              ),
              const SizedBox(width: 4),
              Icon(
                Icons.link,
                color: AppColors.textGray,
                size: 14,
              ),
            ],
          ),
          const SizedBox(height: 4),
          // Client name
          Text(
            clientName,
            style: TextStyle(
              color: AppColors.textGray,
              fontSize: 12,
            ),
          ),
          const SizedBox(height: 12),
          // Budget hours
          Row(
            children: [
              Text(
                'Budget Hours',
                style: TextStyle(
                  color: AppColors.textGray,
                  fontSize: 12,
                ),
              ),
              const SizedBox(width: 4),
              Icon(
                Icons.info_outline,
                color: AppColors.textGray,
                size: 12,
              ),
            ],
          ),
          const SizedBox(height: 8),
          // Progress bar
          ClipRRect(
            borderRadius: BorderRadius.circular(4),
            child: LinearProgressIndicator(
              value: progressValue,
              minHeight: 6,
              backgroundColor: AppColors.borderGray,
              valueColor: AlwaysStoppedAnimation<Color>(
                progressValue > 0.7 ? AppColors.secondaryOrange : AppColors.chartGreen,
              ),
            ),
          ),
        ],
      ),
    );
  }
}
