import 'package:flutter/material.dart';
import '../constants/app_colors.dart';

class TotalReceivablesCard extends StatelessWidget {
  const TotalReceivablesCard({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.only(bottom: 16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(4),
        border: Border.all(color: AppColors.borderGray),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Header
          Padding(
            padding: const EdgeInsets.all(16),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                const Text(
                  'Total Receivables',
                  style: TextStyle(
                    fontSize: 16,
                    fontWeight: FontWeight.w500,
                  ),
                ),
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                  decoration: BoxDecoration(
                    color: AppColors.primaryBlue.withOpacity(0.1),
                    borderRadius: BorderRadius.circular(4),
                  ),
                  child: Row(
                    children: [
                      Icon(Icons.add_circle_outline, color: AppColors.primaryBlue, size: 16),
                      const SizedBox(width: 4),
                      Text(
                        'New',
                        style: TextStyle(
                          color: AppColors.primaryBlue,
                          fontSize: 12,
                          fontWeight: FontWeight.w500,
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),

          // Total amount
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            child: Text(
              'Total Receivables \$372,580.05',
              style: TextStyle(
                color: AppColors.textGray,
                fontSize: 14,
              ),
            ),
          ),

          // Progress bar
          Padding(
            padding: const EdgeInsets.all(16),
            child: ClipRRect(
              borderRadius: BorderRadius.circular(4),
              child: LinearProgressIndicator(
                value: 0.95, // Most of the amount is > 45 days
                minHeight: 8,
                backgroundColor: AppColors.borderGray,
                valueColor: AlwaysStoppedAnimation<Color>(AppColors.secondaryOrange),
              ),
            ),
          ),

          // Payment categories
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            child: Row(
              children: [
                _buildPaymentCategory('CURRENT', '\$0.00', AppColors.textGray),
                const Spacer(),
                _buildPaymentCategory('OVERDUE', '\$12.06', AppColors.secondaryOrange),
                const Spacer(),
                _buildPaymentCategory('\$0.00', '16-30 Days', AppColors.textGray),
                const Spacer(),
                _buildPaymentCategory('\$0.00', '31-45 Days', AppColors.textGray),
                const Spacer(),
                _buildPaymentCategory('\$372,567.99', 'Above 45 days', AppColors.textGray),
              ],
            ),
          ),

          const SizedBox(height: 16),
        ],
      ),
    );
  }

  Widget _buildPaymentCategory(String amount, String label, Color color) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          amount,
          style: TextStyle(
            fontSize: 16,
            fontWeight: FontWeight.w500,
            color: color,
          ),
        ),
        const SizedBox(height: 4),
        Text(
          label,
          style: TextStyle(
            fontSize: 12,
            color: AppColors.textGray,
          ),
        ),
      ],
    );
  }
}
